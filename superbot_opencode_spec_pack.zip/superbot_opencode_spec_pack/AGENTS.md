# Superbot — OpenCode Project Instructions

## Mandatory first reads

Read these files before making application changes:
1. `rules.md`
2. `PRD.md`
3. `context.md`
4. `architecture.md`
5. `task.md`
6. The domain-specific file relevant to the task (`agents.md`, `schema.md`, `design.md`, `Debug.md`, `memory.md`).

Use `task.md` as the implementation queue/status ledger and `context.md` as the current factual snapshot. Detailed requirements elsewhere remain binding.

## Operating model

- This is a new standalone Superbot project. Do not reuse GoldMasters as its base, copy its architecture blindly, or claim a repository integration exists until inspected and tested.
- Work one small, verifiable vertical slice at a time. Use the ECC-controlled build loop in `rules.md`; use installed ECC commands only after checking what is actually available in the current session.
- Start with repository/config/tool reconnaissance and a plan. Do not overwrite a working tree or generate a large scaffold before establishing current state.
- Build a deterministic Python-first local application. AI may propose/review; deterministic code validates; risk gates decide.
- Initial scope is research and simulation only. No live orders. MT5 must be read-only for V1 market data/account metadata and only after explicit setup. Demo trading requires a future named human approval gate and is not authorized by this build instruction.
- Never use live broker credentials, submit orders, alter real trading accounts, send secrets to external services, or expose a public dashboard.
- Do not invent test results, repository facts, commands, dependencies, machine capabilities, instrument specifications, or decisions. Label uncertainty and preserve evidence.
- Do not assume every listed repository must be integrated. Evaluate each by capability and evidence. Reuse ideas if a full integration is unjustified.
- Do not add a new technology/dependency just because a candidate repository uses it. Benchmark and record ADRs for consequential choices.

## Definition of done for every task

A task is not done until:
1. Acceptance criteria are explicit and testable.
2. A focused test exists and passes; write tests before/alongside implementation (red/green/refactor when feasible).
3. Relevant regression and safety tests pass.
4. Independent review or explicit self-review checks edge cases, safety, leakage, state mutation and resource effects.
5. Exact test commands/outcomes, limitations and relevant commit/version identifiers are recorded.
6. `task.md` is updated; other specs are updated whenever their facts/decisions change.
7. No unresolved critical/high-severity defect remains within task scope.
8. The actual diff is inspected; no secrets, generated junk or unrelated changes are included.

## Tool/MCP/skill discipline

At the start enumerate the actual OpenCode version, commands, agents, MCPs, skills, plugins and permission state. The user has previously reported Context7, GitHub, OpenCode Console, Playwright, Ruflo, Sequential Thinking, Stitch, Supabase and Terminal, plus ECC, GSD-Core, OpenCode DCP, Ponytail, Supermemory, Vercel, Superpowers and related tools. Treat this as a discovery checklist, not proof that every item is currently available or suitable.

- **ECC:** inspect active installation/version and command list. Use loop-start/status, quality-gate, harness-audit, review/test/security commands only if they actually exist; otherwise perform the equivalent documented manual loop and record availability.
- **Context7:** prefer current official docs when API/version behavior is uncertain.
- **GitHub:** inspect official repository metadata, source, releases/commits, tests and issues; record immutable adopted commit SHAs.
- **Terminal:** run exact commands and capture actual exit codes/output.
- **Playwright:** browser/UI tests only once a real target app exists. Do not claim visual verification without a run or supplied screenshot.
- **Ruflo:** only if installed capabilities add value for a bounded agent-graph test; it never replaces deterministic orchestration or risk services.
- **Sequential Thinking:** use for complex decomposition/review if available; record conclusions, not hidden chain-of-thought.
- **Stitch:** UI design exploration only if the tool is actually available; specs and tested implementation remain authoritative.
- **Supabase:** optional metadata/report/backup role only after a specific decision. Local PostgreSQL/application data is authoritative. Never sync secrets or require cloud access for offline core operation.
- **GSD-Core / Superpowers / other skills:** inspect actual skill files; invoke relevant workflows only; avoid duplicate/overlapping harness installations.
- **Vercel:** do not deploy this local-first app publicly. Use only if a later user-approved need exists.
- **Supermemory/external memory:** no secrets, credentials, private financial data or unapproved private data. Repository Markdown remains the project source of truth.

If a tool is unavailable, state that fact and use a safe equivalent; never invent tool output.

## Document updates

After each completed task, update `task.md` and affected specs. At every milestone update `context.md` with branch/commit, implementation, exact checks, failed/skipped tests, limitations and next task. If a command fails, follow `Debug.md` before another attempt.
